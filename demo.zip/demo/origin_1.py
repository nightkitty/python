from PIL import Image
import numpy
import os

def listdir_nohidden(path):
    for f in os.listdir(path):
        if not f.startswith('.'):
            yield f

def pretreatment(ima):
    ima=ima.convert('L')        
    im=numpy.array(ima)         
    for i in range(im.shape[0]):
        for j in range(im.shape[1]):
            if im[i,j] > 196 :
                im[i,j]=1
            else:
                im[i,j]=0
    return im

def tra_pretreatment(ima):
    ima=ima.convert('L')        
    im=numpy.array(ima)         
    for i in range(im.shape[0]):
        for j in range(im.shape[1]):
            if im[i,j] < 196 :
                im[i,j]=1
            else:
                im[i,j]=0
    return im


def feature(A):
    x=A.shape[1]
    y=A.shape[0]
    midx=int(x/2)+1
    mi1y=int(y/4)+1
    mi3y=int(y*0.75)+1

    A1=r_loop(A,0,y,midx,1)
    A2=r_loop(A,0,x,mi1y,0)
    A3=r_loop(A,0,x,mi3y,0)
    A4=r_loop(A,0,midx,mi3y,0)
    A5=r_loop(A,0,midx,mi1y,0)
    AF=[A1,A2,A3,A4,A5]
    return AF

#**************************************************************************************

def training():
    train_set={}
    for i in range(10):
        value=[]
        for j in listdir_nohidden('/Users/darkness/Documents/Python_3/demo/'+str(i)):
            ima=Image.open('/Users/darkness/Documents/Python_3/demo/'+str(i)+'/'+str(j))
            im=tra_pretreatment(ima)
            value.append(feature(im))
        #****************************************************
        train_set[i]=value
    return train_set

def identification(train_set,AF):
    result=''
    k=0
    for i in AF:
        k=k+1
        key=knn(train_set,i)
        result=result+str(key)
        if k%3==0:
            result = result+' '
    return str(result)


def knn(train_set,V):
    kingkey=1
    for key in range(10):
        for value in train_set[key]:
            if V == value:
                kingkey=key
                break
    return kingkey

def incise(im):
    a=[];b=[]
    for i in range(im.shape[1]-1):
        if all(im[:,i]==0) and any(im[:,i+1]==1):
            a.append(i+1)
        elif any(im[:,i]==1) and all(im[:,i+1]==0):
            b.append(i+1)
    AF=[]
    for i in range(len(a)):
        imp = im[:,range(a[i],b[i])]
        AF.append(feature(incise_x(imp)))
    return AF

def incise_x(imp):
    c=0;d=0
    for j in range(imp.shape[0]-1):
        if all(imp[j,:]==0) and any(imp[j+1,:]==1):
            c=j+1
        elif any(imp[j,:]==1) and all(imp[j+1,:]==0):
            d=j+1
    NI = imp[range(c,d),:]
    return NI

def r_loop(img,a,b,c,x_y):
    num = 0
    if x_y==0:
        for i in range(a,b):
            if img[c,i]==1 and (i==0 or img[c,i-1]==0):
                num =num + 1
    else :
        for i in range(a,b):
            if img[i,c]==1 and (i==0 or img[i-1,c]==0):
                num =num + 1
    return num

def class_Test():
    train_set = training()
    backups=[]
    for i in listdir_nohidden('/Users/darkness/Documents/Python_3/demo/data/'):
        ima=Image.open('/Users/darkness/Documents/Python_3/demo/data/'+str(i))
        im=pretreatment(ima)
        AF=incise(im)
        #*************************************************
        result=identification(train_set,AF)
        backups.append(result)
    f=open('f.txt','w')
    for j in backups:
        f.write(str(j)+'\n')
    f.close()

if __name__ == '__main__':
    class_Test()
    print('Successful!')


