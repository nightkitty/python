from PIL import Image
import numpy
import os

def listdir_nohidden(path):
    for f in os.listdir(path):
        if not f.startswith('.'):
            yield f

def convert_to_bw(imp):
    im = imp.convert('L')
    threshold  = 196
    table  =  []
    for  i  in  range( 256 ):
        if  i  >  threshold:
            table.append(0)
        else :
            table.append( 1 )
 
    im  =  im.point(table,'1')
    return im

def pretreatment(ima):
    ima=ima.convert('L')        #转化为灰度图像
    im=numpy.array(ima)         #转化为二维数组
    for i in range(im.shape[0]):#转化为二值矩阵
        for j in range(im.shape[1]):
            if im[i,j] > 196 :
                im[i,j]=1
            else:
                im[i,j]=0
    return im

def incise(im):
    a=[];b=[]
    if any(im[:,0]==1):
        a.append(0)
    for i in range(im.shape[1]-1):
        if all(im[:,i]==0) and any(im[:,i+1]==1):
            a.append(i+1)
        elif any(im[:,i]==1) and all(im[:,i+1]==0):
            b.append(i+1)
    if any(im[:,im.shape[1]-1]==1):
        b.append(im.shape[1])
    AF=[]
    print(a)
    print(b)
    for i in range(len(a)):
        imp = im[:,range(a[i],b[i])]
        AF.append(incise_x(imp,a[i],b[i]))
    return AF

def incise_x(imp,a,b):
    c=0
    d=0
    for j in range(imp.shape[0]-1):
        if all(imp[j,:]==0) and any(imp[j+1,:]==1):
            c=j+1
        elif any(imp[j,:]==1) and all(imp[j+1,:]==0):
            d=j+1
    NI = [a,b,c,d]
    print(NI)
    return NI

def get_test_imgs(Filename):
    num = 0
    for i in Filename:
        im = Image.open('/Users/darkness/Documents/Python_3/demo/data/'+str(i))
        imp = pretreatment(im)
        localdata = incise(imp)
        im = convert_to_bw(im)
        array_0 = get_crop_imgs(localdata,im)
        for j in array_0:
            j.save('/Users/darkness/Documents/Python_3/demo/test/'+str(num)+'.bmp')
            num = num + 1

def get_crop_imgs(all_Data,img):
    child_img_list = []
    for data in all_Data:
        child_img = img.crop((data[0], data[2], data[1], data[3]))
        child_img_list.append(child_img)
    return child_img_list

def class_Test():
    training_File_List = listdir_nohidden('/Users/darkness/Documents/Python_3/demo/data/')
    get_test_imgs(training_File_List)


if __name__ == '__main__':
    class_Test()
    print('Successful!')
